
package com.loophack.overlay

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.*
import android.graphics.drawable.GradientDrawable
import androidx.activity.result.contract.ActivityResultContracts

class MainActivity : Activity() {

    private val pink = Color.rgb(240, 0, 216)
    private lateinit var root: LinearLayout

    private val imagePicker =
        registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
            uri?.let {
                try {
                    contentResolver.takePersistableUriPermission(
                        it,
                        Intent.FLAG_GRANT_READ_URI_PERMISSION
                    )
                } catch (_: Exception) {}
                addOverlay("image", it.toString())
            }
        }

    private val videoPicker =
        registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
            uri?.let {
                try {
                    contentResolver.takePersistableUriPermission(
                        it,
                        Intent.FLAG_GRANT_READ_URI_PERMISSION
                    )
                } catch (_: Exception) {}
                addOverlay("video", it.toString())
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
    }

    private fun background(color: Int): GradientDrawable {
        return GradientDrawable().apply {
            setColor(color)
            cornerRadius = 22f
            setStroke(1, pink)
        }
    }

    private fun buildUi() {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(22, 24, 22, 24)
            setBackgroundColor(Color.rgb(16, 4, 20))
        }

        val scroll = ScrollView(this)
        scroll.addView(root)

        val logo = ImageView(this).apply {
            setImageResource(R.drawable.loop_logo)
            scaleType = ImageView.ScaleType.FIT_CENTER
        }

        root.addView(logo, LinearLayout.LayoutParams(110, 110).apply {
            gravity = Gravity.CENTER
        })

        addLabel("LOOP HACK", 29f, Color.WHITE, true, Gravity.CENTER)
        addLabel("STREAM OVERLAY STUDIO", 11f, pink, true, Gravity.CENTER)
        addSpace(25)

        addLabel(
            "Создавай собственные элементы поверх экрана",
            16f, Color.WHITE, true
        )
        addLabel(
            "Текст • фотографии • видео • свободное размещение",
            12f, 0xFFBDA9C2.toInt(), false
        )

        addSpace(20)
        addSection("СОЗДАТЬ ОВЕРЛЕЙ")

        addButton("＋  Добавить текст") {
            showTextDialog()
        }

        addButton("▧  Добавить фото") {
            imagePicker.launch(arrayOf("image/*"))
        }

        addButton("▶  Добавить видео") {
            videoPicker.launch(arrayOf("video/*"))
        }

        addSpace(14)
        addSection("УПРАВЛЕНИЕ")

        addButton("Разрешение поверх приложений") {
            requestPermission()
        }

        addButton("▶  Запустить оверлеи") {
            if (Settings.canDrawOverlays(this)) {
                OverlayService.start(this)
            } else {
                requestPermission()
            }
        }

        addButton("Скрыть / показать оверлеи") {
            sendCommand(OverlayService.ACTION_TOGGLE)
        }

        addButton("Закрепить / открепить всё") {
            sendCommand(OverlayService.ACTION_LOCK)
        }

        addButton("Удалить все элементы") {
            sendCommand(OverlayService.ACTION_CLEAR)
        }

        addSpace(15)
        addSection("ИНСТРУКЦИЯ")

        addLabel(
            "1. Разреши отображение поверх других окон.\n" +
            "2. Добавь текст, фото или видео.\n" +
            "3. Перемещай элементы пальцем.\n" +
            "4. Масштабируй двумя пальцами.\n" +
            "5. Переключись в TikTok и включи демонстрацию экрана.",
            13f, 0xFFD7C8DB.toInt(), false
        )

        addSpace(20)

        addButton("НАШ TELEGRAM-КАНАЛ") {
            val intent = Intent(
                Intent.ACTION_VIEW,
                Uri.parse("https://t.me/ExtraCheatStanddof2")
            )
            startActivity(intent)
        }

        addSpace(12)
        addLabel(
            "LOOP HACK • CREATED FOR STREAMS",
            10f, pink, true, Gravity.CENTER
        )

        setContentView(scroll)
    }

    private fun addLabel(
        text: String,
        size: Float,
        color: Int,
        bold: Boolean,
        gravity: Int = Gravity.START
    ) {
        val view = TextView(this).apply {
            this.text = text
            textSize = size
            setTextColor(color)
            this.gravity = gravity
            if (bold) typeface = Typeface.DEFAULT_BOLD
            setPadding(0, 5, 0, 5)
        }
        root.addView(view)
    }

    private fun addSpace(height: Int) {
        root.addView(View(this), LinearLayout.LayoutParams(1, height))
    }

    private fun addSection(text: String) {
        addLabel(text, 12f, pink, true)
    }

    private fun addButton(
        text: String,
        action: () -> Unit
    ) {
        val button = TextView(this).apply {
            this.text = text
            textSize = 14f
            gravity = Gravity.CENTER
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.WHITE)
            background = background(0xFF29102F.toInt())
            setPadding(12, 16, 12, 16)

            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply {
                bottomMargin = 10
                topMargin = 4
            }

            setOnClickListener { action() }
        }

        root.addView(button)
    }

    private fun showTextDialog() {
        val input = EditText(this).apply {
            hint = "Например: Мой Telegram @username"
            setTextColor(Color.WHITE)
            setHintTextColor(0xFFAA99AA.toInt())
            setPadding(20, 15, 20, 15)
        }

        val container = LinearLayout(this).apply {
            setPadding(20, 5, 20, 0)
            addView(input)
        }

        android.app.AlertDialog.Builder(this)
            .setTitle("Новый оверлей")
            .setView(container)
            .setPositiveButton("Добавить") { _, _ ->
                val value = input.text.toString().trim()
                if (value.isNotEmpty()) {
                    addOverlay("text", value)
                }
            }
            .setNegativeButton("Отмена", null)
            .show()
    }

    private fun requestPermission() {
        if (!Settings.canDrawOverlays(this)) {
            startActivity(
                Intent(
                    Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:$packageName")
                )
            )
        } else {
            Toast.makeText(
                this,
                "Разрешение уже включено",
                Toast.LENGTH_SHORT
            ).show()
        }
    }

    private fun addOverlay(type: String, data: String) {
        if (!Settings.canDrawOverlays(this)) {
            requestPermission()
            Toast.makeText(
                this,
                "Сначала разреши оверлеи",
                Toast.LENGTH_SHORT
            ).show()
            return
        }

        val intent = Intent(this, OverlayService::class.java).apply {
            action = OverlayService.ACTION_ADD
            putExtra("type", type)
            putExtra("data", data)
        }

        startServiceCompat(intent)
    }

    private fun sendCommand(action: String) {
        if (!Settings.canDrawOverlays(this)) {
            requestPermission()
            return
        }

        val intent = Intent(this, OverlayService::class.java).apply {
            this.action = action
        }

        startServiceCompat(intent)
    }

    private fun startServiceCompat(intent: Intent) {
        if (android.os.Build.VERSION.SDK_INT >= 26) {
            startForegroundService(intent)
        } else {
            startService(intent)
        }
    }
}
