
package com.loophack.overlay

import android.app.*
import android.content.*
import android.graphics.*
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.*
import android.provider.Settings
import android.view.*
import android.widget.*
import kotlin.math.sqrt

class OverlayService : Service() {

    companion object {
        const val ACTION_ADD = "com.loophack.overlay.ADD"
        const val ACTION_TOGGLE = "com.loophack.overlay.TOGGLE"
        const val ACTION_LOCK = "com.loophack.overlay.LOCK"
        const val ACTION_CLEAR = "com.loophack.overlay.CLEAR"

        fun start(context: Context) {
            val intent = Intent(context, OverlayService::class.java)
            if (Build.VERSION.SDK_INT >= 26) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
        }
    }

    private lateinit var windowManager: WindowManager

    private data class Layer(
        val view: View,
        val params: WindowManager.LayoutParams
    )

    private val layers = mutableListOf<Layer>()

    private var visible = true
    private var locked = false

    private val pink = Color.rgb(240, 0, 216)

    override fun onCreate() {
        super.onCreate()

        windowManager =
            getSystemService(WINDOW_SERVICE) as WindowManager

        createNotification()
    }

    private fun createNotification() {
        val channelId = "loop_hack_overlay"

        if (Build.VERSION.SDK_INT >= 26) {
            val manager =
                getSystemService(NOTIFICATION_SERVICE) as NotificationManager

            manager.createNotificationChannel(
                NotificationChannel(
                    channelId,
                    "LOOP HACK",
                    NotificationManager.IMPORTANCE_LOW
                )
            )
        }

        val notification = if (Build.VERSION.SDK_INT >= 26) {
            Notification.Builder(this, channelId)
                .setSmallIcon(android.R.drawable.ic_menu_view)
                .setContentTitle("LOOP HACK активен")
                .setContentText("Оверлеи работают")
                .setOngoing(true)
                .build()
        } else {
            Notification.Builder(this)
                .setSmallIcon(android.R.drawable.ic_menu_view)
                .setContentTitle("LOOP HACK активен")
                .build()
        }

        startForeground(77, notification)
    }

    override fun onStartCommand(
        intent: Intent?,
        flags: Int,
        startId: Int
    ): Int {

        when (intent?.action) {

            ACTION_ADD -> {
                val type = intent.getStringExtra("type") ?: "text"
                val data = intent.getStringExtra("data") ?: ""
                addLayer(type, data)
            }

            ACTION_TOGGLE -> {
                visible = !visible
                layers.forEach {
                    it.view.visibility =
                        if (visible) View.VISIBLE else View.GONE
                }
            }

            ACTION_LOCK -> {
                locked = !locked
            }

            ACTION_CLEAR -> {
                removeAllLayers()
            }
        }

        return START_STICKY
    }

    private fun makeParams(): WindowManager.LayoutParams {

        val type =
            if (Build.VERSION.SDK_INT >= 26) {
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            } else {
                WindowManager.LayoutParams.TYPE_PHONE
            }

        return WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = dp(70)
            y = dp(240)
        }
    }

    private fun addLayer(type: String, data: String) {

        if (!Settings.canDrawOverlays(this)) return

        val frame = FrameLayout(this).apply {
            background = GradientDrawable().apply {
                setColor(0x5520082A)
                setStroke(dp(1), pink)
                cornerRadius = dp(12).toFloat()
            }

            setPadding(dp(8), dp(8), dp(8), dp(8))
        }

        val content: View = when (type) {

            "image" -> {
                ImageView(this).apply {
                    setImageURI(Uri.parse(data))
                    scaleType = ImageView.ScaleType.FIT_CENTER
                    adjustViewBounds = true

                    layoutParams = FrameLayout.LayoutParams(
                        dp(180),
                        dp(150)
                    )
                }
            }

            "video" -> {
                VideoView(this).apply {
                    layoutParams = FrameLayout.LayoutParams(
                        dp(220),
                        dp(150)
                    )

                    setVideoURI(Uri.parse(data))

                    setOnPreparedListener {
                        it.isLooping = true
                        start()
                    }

                    setOnErrorListener { _, _, _ ->
                        Toast.makeText(
                            this@OverlayService,
                            "Не удалось воспроизвести видео",
                            Toast.LENGTH_SHORT
                        ).show()
                        true
                    }
                }
            }

            else -> {
                TextView(this).apply {
                    text = data
                    textSize = 22f
                    setTextColor(Color.WHITE)

                    typeface = Typeface.create(
                        "sans-serif-black",
                        Typeface.BOLD
                    )

                    setShadowLayer(9f, 0f, 0f, pink)
                    gravity = Gravity.CENTER
                    setPadding(dp(6), dp(5), dp(6), dp(5))
                }
            }
        }

        frame.addView(content)

        val delete = TextView(this).apply {
            text = "×"
            textSize = 18f
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)

            background = GradientDrawable().apply {
                setColor(0xFFB00082.toInt())
                cornerRadius = dp(20).toFloat()
            }
        }

        frame.addView(
            delete,
            FrameLayout.LayoutParams(
                dp(27),
                dp(27),
                Gravity.TOP or Gravity.END
            )
        )

        val params = makeParams()

        val layer = Layer(frame, params)

        delete.setOnClickListener {
            removeLayer(layer)
        }

        attachGestures(layer)

        try {
            windowManager.addView(frame, params)
            layers.add(layer)

            frame.visibility =
                if (visible) View.VISIBLE else View.GONE

        } catch (e: Exception) {
            Toast.makeText(
                this,
                "Ошибка создания оверлея",
                Toast.LENGTH_SHORT
            ).show()
        }
    }

    private fun attachGestures(layer: Layer) {

        val view = layer.view
        val params = layer.params

        var startX = 0
        var startY = 0

        var downX = 0f
        var downY = 0f

        var initialDistance = 0f
        var initialScale = 1f

        view.setOnTouchListener { _, event ->

            if (locked) return@setOnTouchListener true

            when (event.actionMasked) {

                MotionEvent.ACTION_DOWN -> {

                    downX = event.rawX
                    downY = event.rawY

                    startX = params.x
                    startY = params.y

                    true
                }

                MotionEvent.ACTION_POINTER_DOWN -> {

                    if (event.pointerCount >= 2) {
                        initialDistance = distance(event)
                        initialScale = view.scaleX
                    }

                    true
                }

                MotionEvent.ACTION_MOVE -> {

                    if (
                        event.pointerCount >= 2 &&
                        initialDistance > 0f
                    ) {

                        val factor =
                            distance(event) / initialDistance

                        val scale =
                            (initialScale * factor).coerceIn(0.4f, 4f)

                        view.scaleX = scale
                        view.scaleY = scale

                    } else if (event.pointerCount == 1) {

                        params.x =
                            startX + (event.rawX - downX).toInt()

                        params.y =
                            startY + (event.rawY - downY).toInt()

                        try {
                            windowManager.updateViewLayout(
                                view,
                                params
                            )
                        } catch (_: Exception) {}
                    }

                    true
                }

                MotionEvent.ACTION_POINTER_UP -> {
                    initialDistance = 0f
                    true
                }

                MotionEvent.ACTION_UP -> {
                    true
                }

                else -> true
            }
        }
    }

    private fun distance(event: MotionEvent): Float {

        if (event.pointerCount < 2) return 0f

        val dx = event.getX(0) - event.getX(1)
        val dy = event.getY(0) - event.getY(1)

        return sqrt(dx * dx + dy * dy).coerceAtLeast(1f)
    }

    private fun removeLayer(layer: Layer) {

        try {
            windowManager.removeView(layer.view)
        } catch (_: Exception) {}

        layers.remove(layer)
    }

    private fun removeAllLayers() {

        layers.toList().forEach {
            removeLayer(it)
        }
    }

    private fun dp(value: Int): Int {
        return (
            value * resources.displayMetrics.density
        ).toInt()
    }

    override fun onDestroy() {
        removeAllLayers()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
